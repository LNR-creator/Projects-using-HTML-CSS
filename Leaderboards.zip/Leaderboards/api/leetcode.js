// /api/leetcode.js
export default async function handler(req, res) {
  const { username } = req.query;

  if (!username) {
    return res.status(400).json({ error: 'Username is required' });
  }

  // GraphQL query to get problem stats
  const graphqlQuery = {
    query: `
      query getUserProfile($username: String!) {
        matchedUser(username: $username) {
          submitStats {
            acSubmissionNum {
              difficulty
              count
            }
          }
        }
      }
    `,
    variables: { username }
  };

  try {
    const response = await fetch('https://leetcode.com/graphql', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(graphqlQuery),
    });

    // LeetCode sometimes returns HTML if the username is invalid, so we parse safely
    const contentType = response.headers.get('content-type') || '';
    if (!contentType.includes('application/json')) {
      return res.status(500).json({ error: 'Unexpected LeetCode response format' });
    }

    const data = await response.json();
    return res.status(200).json(data.data);
  } catch (error) {
    console.error('LeetCode API error:', error);
    return res.status(500).json({ error: 'Failed to fetch data from LeetCode' });
  }
}
