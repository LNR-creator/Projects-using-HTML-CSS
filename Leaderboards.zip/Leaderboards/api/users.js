import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY
);

export default async function handler(req, res) {
  try {
    if (req.method === 'GET') {
      const { data, error } = await supabase
        .from('users')
        .select('username')
        .order('id', { ascending: true });

      if (error) throw error;
      return res.status(200).json(data);
    }

    if (req.method === 'POST') {
      const { username } = req.body;
      if (!username) {
        return res.status(400).json({ error: 'Username required' });
      }

      const { error } = await supabase
        .from('users')
        .insert([{ username }]);

      if (error) throw error;
      return res.status(201).json({ success: true });
    }

    if (req.method === 'DELETE') {
      const { username } = req.query;
      if (!username) {
        return res.status(400).json({ error: 'Username required' });
      }

      const { error } = await supabase
        .from('users')
        .delete()
        .eq('username', username);

      if (error) throw error;
      return res.status(200).json({ success: true });
    }

    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('Supabase API error:', err.message);
    res.status(500).json({ error: err.message });
  }
}
